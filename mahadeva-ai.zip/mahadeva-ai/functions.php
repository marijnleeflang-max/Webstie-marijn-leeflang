<?php
/**
 * Mahadeva AI functions and definitions
 *
 * @package Mahadeva_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MAHADEVA_VERSION', '1.0.0' );

/**
 * Theme setup.
 */
function mahadeva_setup() {
	load_theme_textdomain( 'mahadeva-ai', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
		'navigation-widgets',
	) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'editor-styles' );

	set_post_thumbnail_size( 1200, 800, true );

	register_nav_menus( array(
		'primary'         => __( 'Primary Menu', 'mahadeva-ai' ),
		'footer-navigation'=> __( 'Footer Navigation', 'mahadeva-ai' ),
		'footer-company'  => __( 'Footer Company', 'mahadeva-ai' ),
	) );
}
add_action( 'after_setup_theme', 'mahadeva_setup' );

/**
 * Enqueue scripts and styles.
 */
function mahadeva_scripts() {
	wp_enqueue_style( 'mahadeva-fonts', 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'mahadeva-style', get_stylesheet_uri(), array(), MAHADEVA_VERSION );

	wp_enqueue_script( 'mahadeva-main', get_template_directory_uri() . '/assets/js/main.js', array(), MAHADEVA_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'mahadeva_scripts' );

/**
 * Register widget area (footer / blog sidebar).
 */
function mahadeva_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'mahadeva-ai' ),
		'id'            => 'sidebar-blog',
		'description'   => __( 'Shown on blog archive and single post pages.', 'mahadeva-ai' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'mahadeva_widgets_init' );

/**
 * Includes.
 */
require get_template_directory() . '/inc/custom-post-types.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/sample-content.php';

/**
 * Excerpt length / ellipsis.
 */
function mahadeva_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'mahadeva_excerpt_length' );

function mahadeva_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'mahadeva_excerpt_more' );

/**
 * Fallback menu for primary nav when none assigned.
 */
function mahadeva_fallback_menu() {
	echo '<ul>';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'mahadeva-ai' ) . '</a></li>';
	$pages = get_pages( array( 'sort_column' => 'menu_order', 'number' => 5 ) );
	foreach ( $pages as $page ) {
		echo '<li><a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( $page->post_title ) . '</a></li>';
	}
	echo '</ul>';
}

/**
 * Pixel-icon helper: returns inline SVG square/dot icon markup used across feature cards.
 */
function mahadeva_icon( $key = 'spark' ) {
	$icons = array(
		'spark'  => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 0L12 8L20 10L12 12L10 20L8 12L0 10L8 8L10 0Z" fill="#fff"/></svg>',
		'square' => '<svg width="16" height="16" viewBox="0 0 16 16"><rect width="16" height="16" fill="#fff"/></svg>',
		'bolt'   => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M11 0L2 12H9L8 20L18 7H11L11 0Z" fill="#fff"/></svg>',
	);
	return isset( $icons[ $key ] ) ? $icons[ $key ] : $icons['spark'];
}
