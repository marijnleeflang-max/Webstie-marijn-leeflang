<?php
/**
 * Search results template.
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<div class="page-banner" style="padding-top:0;">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Search Results', 'mahadeva-ai' ); ?></p>
			<h1>
				<?php
				printf(
					/* translators: %s: search query. */
					esc_html__( 'Results for: %s', 'mahadeva-ai' ),
					'<em>' . esc_html( get_search_query() ) . '</em>'
				);
				?>
			</h1>
		</div>

		<?php if ( have_posts() ) : ?>
			<div class="blog-grid">
				<?php while ( have_posts() ) : the_post(); ?>
					<a class="post-card" href="<?php the_permalink(); ?>">
						<div class="thumb">
							<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'medium_large' ); endif; ?>
						</div>
						<div class="body">
							<span class="meta"><?php echo esc_html( get_post_type() ); ?></span>
							<h3><?php the_title(); ?></h3>
							<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 16 ) ); ?></p>
						</div>
					</a>
				<?php endwhile; ?>
			</div>
			<?php mahadeva_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'No results found. Try a different search.', 'mahadeva-ai' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
