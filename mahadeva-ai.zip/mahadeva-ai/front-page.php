<?php
/**
 * Front page template.
 *
 * @package Mahadeva_AI
 */

get_header();

$hero_heading = get_theme_mod( 'hero_heading', __( 'Custom AI Solutions to Increase Revenue', 'mahadeva-ai' ) );
$accent       = get_theme_mod( 'hero_heading_accent', __( 'Increase Revenue', 'mahadeva-ai' ) );
$heading_html = esc_html( $hero_heading );
if ( $accent && false !== strpos( $hero_heading, $accent ) ) {
	$heading_html = str_replace( esc_html( $accent ), '<span class="accent">' . esc_html( $accent ) . '</span>', esc_html( $hero_heading ) );
}
?>

<main id="main" class="site-main">

	<!-- HERO -->
	<section class="hero">
		<div class="container hero-inner">
			<p class="hero-tag"><i></i><?php echo esc_html( get_theme_mod( 'hero_tag', __( 'AI Automation Studio', 'mahadeva-ai' ) ) ); ?></p>
			<h1><?php echo wp_kses_post( $heading_html ); ?></h1>
			<p class="lede"><?php echo esc_html( get_theme_mod( 'hero_subheading', __( 'We build intelligent systems that automate decisions, boost productivity, and drive scalable growth for modern teams.', 'mahadeva-ai' ) ) ); ?></p>
			<div class="hero-actions">
				<a class="btn btn-primary" href="<?php echo esc_url( get_theme_mod( 'hero_btn1_url', '#contact' ) ); ?>"><?php echo esc_html( get_theme_mod( 'hero_btn1_text', __( 'Get Free Consultation', 'mahadeva-ai' ) ) ); ?></a>
				<a class="btn btn-outline" href="<?php echo esc_url( get_theme_mod( 'hero_btn2_url', '#work' ) ); ?>"><?php echo esc_html( get_theme_mod( 'hero_btn2_text', __( 'Explore Our Work', 'mahadeva-ai' ) ) ); ?></a>
			</div>
		</div>
	</section>

	<!-- CLIENT LOGOS -->
	<?php
	$logos = new WP_Query( array( 'post_type' => 'client_logo', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $logos->have_posts() ) :
		?>
		<div class="logo-strip">
			<div class="container">
				<div class="marquee">
					<?php
					while ( $logos->have_posts() ) : $logos->the_post();
						echo get_the_post_thumbnail( get_the_ID(), 'medium', array( 'alt' => get_the_title() ) );
					endwhile;
					wp_reset_postdata();
					// duplicate for seamless marquee loop
					$logos->rewind_posts();
					while ( $logos->have_posts() ) : $logos->the_post();
						echo get_the_post_thumbnail( get_the_ID(), 'medium', array( 'alt' => get_the_title() ) );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<!-- STATEMENT -->
	<section class="section statement">
		<div class="container">
			<p class="eyebrow" style="justify-content:center;"><?php echo esc_html( get_theme_mod( 'statement_eyebrow', __( 'AI First Agency', 'mahadeva-ai' ) ) ); ?></p>
			<p class="headline"><?php echo esc_html( get_theme_mod( 'statement_text', __( 'Mahadeva helps ambitious brands transform AI into practical systems that automate work, boost efficiency, and drive measurable growth across teams.', 'mahadeva-ai' ) ) ); ?></p>
		</div>
	</section>

	<!-- FEATURES -->
	<section class="section" style="padding-top:0;">
		<div class="container">
			<div class="section-head center">
				<h2 class="headline"><?php esc_html_e( 'Everything You Need to Scale With AI', 'mahadeva-ai' ); ?></h2>
			</div>
			<div class="features-grid">
				<?php
				$features = array(
					array( 'Continuous Improvement', 'Deploy AI that learns over time to improve operational efficiency and productivity.' ),
					array( 'Revenue Optimization', 'Use AI systems designed to increase conversions and overall business productivity.' ),
					array( 'Custom AI Agents', 'Create tailored AI agents built around your workflows and team productivity goals.' ),
					array( 'Data Intelligence', 'Turn operational data into insights that improve decisions and business automation.' ),
					array( 'Workflow Automation', 'Automate repetitive workflows to save time and improve daily team productivity.' ),
					array( 'Smart Integrations', 'Connect AI seamlessly with your tools to streamline team workflows and productivity.' ),
				);
				foreach ( $features as $i => $f ) :
					?>
					<div class="feature-card">
						<div class="icon"><?php echo mahadeva_icon( 'spark' ); ?></div>
						<h3><?php echo esc_html( $f[0] ); ?></h3>
						<p><?php echo esc_html( $f[1] ); ?></p>
						<span class="num"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- CASE STUDIES -->
	<section class="section" id="work">
		<div class="container">
			<div class="section-head" style="display:flex;align-items:flex-end;justify-content:space-between;gap:1.5rem;max-width:none;">
				<div>
					<p class="eyebrow"><?php esc_html_e( 'Latest Work', 'mahadeva-ai' ); ?></p>
					<h2 class="headline mt-0"><?php esc_html_e( 'See the systems in action', 'mahadeva-ai' ); ?></h2>
				</div>
				<a class="btn btn-outline" href="<?php echo esc_url( get_post_type_archive_link( 'case_study' ) ); ?>"><?php esc_html_e( 'More Case Studies', 'mahadeva-ai' ); ?></a>
			</div>
			<div class="case-grid">
				<?php
				$cases = new WP_Query( array( 'post_type' => 'case_study', 'posts_per_page' => 3 ) );
				if ( $cases->have_posts() ) :
					while ( $cases->have_posts() ) : $cases->the_post();
						mahadeva_case_card( get_the_ID() );
					endwhile;
					wp_reset_postdata();
				endif;
				?>
			</div>
		</div>
	</section>

	<!-- STATS -->
	<section class="section" style="padding-top:0;">
		<div class="container">
			<div class="section-head center">
				<h2 class="headline"><?php esc_html_e( 'Why Top Companies Trust Us', 'mahadeva-ai' ); ?></h2>
				<p class="lede" style="margin-inline:auto;"><?php esc_html_e( 'We design AI solutions that automate work, improve performance, and drive business impact.', 'mahadeva-ai' ); ?></p>
			</div>
			<div class="stats-grid">
				<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
					<div class="stat">
						<div class="fig"><?php echo esc_html( get_theme_mod( "stat_{$i}_fig" ) ); ?></div>
						<h4><?php echo esc_html( get_theme_mod( "stat_{$i}_label" ) ); ?></h4>
						<p><?php echo esc_html( get_theme_mod( "stat_{$i}_desc" ) ); ?></p>
					</div>
				<?php endfor; ?>
			</div>
		</div>
	</section>

	<!-- TECH STACK -->
	<?php
	$tools = new WP_Query( array( 'post_type' => 'tech_tool', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $tools->have_posts() ) :
		?>
		<section class="section" style="padding-top:0;">
			<div class="container">
				<div class="section-head center">
					<h2 class="headline"><?php esc_html_e( 'Our Automation Tools & Technology Stack', 'mahadeva-ai' ); ?></h2>
				</div>
				<div class="stack-grid">
					<?php
					while ( $tools->have_posts() ) : $tools->the_post();
						?>
						<div class="stack-item">
							<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'thumbnail' ); else : echo mahadeva_icon( 'square' ); endif; ?>
							<span><?php the_title(); ?></span>
						</div>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<!-- TESTIMONIALS -->
	<?php
	$testis = new WP_Query( array( 'post_type' => 'testimonial', 'posts_per_page' => -1 ) );
	if ( $testis->have_posts() ) :
		?>
		<section class="section" style="padding-top:0;">
			<div class="container">
				<div class="section-head">
					<p class="eyebrow"><?php esc_html_e( 'Testimonials', 'mahadeva-ai' ); ?></p>
					<h2 class="headline mt-0"><?php esc_html_e( 'Results teams are talking about', 'mahadeva-ai' ); ?></h2>
				</div>
			</div>
			<div class="testi-track">
				<?php
				while ( $testis->have_posts() ) : $testis->the_post();
					$name = get_post_meta( get_the_ID(), 'author_name', true ) ?: get_the_title();
					$role = get_post_meta( get_the_ID(), 'author_role', true );
					?>
					<div class="testi-card">
						<p class="quote">&ldquo;<?php echo esc_html( get_the_content() ); ?>&rdquo;</p>
						<div class="person">
							<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'thumbnail' ); endif; ?>
							<div>
								<strong><?php echo esc_html( $name ); ?></strong>
								<span><?php echo esc_html( $role ); ?></span>
							</div>
						</div>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		</section>
	<?php endif; ?>

	<!-- BEFORE / AFTER -->
	<section class="section">
		<div class="container">
			<div class="section-head center">
				<h2 class="headline"><?php esc_html_e( 'Before vs After', 'mahadeva-ai' ); ?></h2>
			</div>
			<div class="compare">
				<div class="compare-col before">
					<p class="tag"><?php esc_html_e( 'Before working with us', 'mahadeva-ai' ); ?></p>
					<h3><?php esc_html_e( 'Manual, disconnected, slow', 'mahadeva-ai' ); ?></h3>
					<p><?php esc_html_e( 'Growth slows when teams rely on manual processes and disconnected systems.', 'mahadeva-ai' ); ?></p>
					<?php
					$before_items = array(
						array( 'Slow Execution Cycles', 'Projects move slowly due to manual approvals and unclear workflows.' ),
						array( 'Operational Overload', 'Teams spend too much time on repetitive tasks instead of strategy.' ),
						array( 'Unclear Performance', 'Lack of automation leads to inconsistent output and missed opportunities.' ),
					);
					foreach ( $before_items as $item ) :
						?>
						<div class="compare-item">
							<span class="mark"></span>
							<div><h4><?php echo esc_html( $item[0] ); ?></h4><p><?php echo esc_html( $item[1] ); ?></p></div>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="compare-col after">
					<p class="tag"><?php esc_html_e( 'After working with us', 'mahadeva-ai' ); ?></p>
					<h3><?php esc_html_e( 'Automated, clear, scalable', 'mahadeva-ai' ); ?></h3>
					<p><?php esc_html_e( 'Automation brings clarity, speed, and scalable systems across every workflow.', 'mahadeva-ai' ); ?></p>
					<?php
					$after_items = array(
						array( 'Accelerated Delivery', 'Workflows move faster with automation supporting execution.' ),
						array( 'Operational Clarity', 'Teams focus on meaningful work instead of repetitive tasks.' ),
						array( 'Scalable Systems', 'Processes become reliable and built for long-term growth.' ),
					);
					foreach ( $after_items as $item ) :
						?>
						<div class="compare-item">
							<span class="mark"></span>
							<div><h4><?php echo esc_html( $item[0] ); ?></h4><p><?php echo esc_html( $item[1] ); ?></p></div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</section>

	<!-- PRICING -->
	<?php
	$plans = new WP_Query( array( 'post_type' => 'pricing_plan', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $plans->have_posts() ) :
		?>
		<section class="section" id="pricing">
			<div class="container">
				<div class="section-head center">
					<h2 class="headline"><?php esc_html_e( 'Flexible Plans for Every Growth Stage', 'mahadeva-ai' ); ?></h2>
					<p class="lede" style="margin-inline:auto;"><?php esc_html_e( 'Mahadeva helps ambitious teams build intelligent automation systems that improve efficiency and unlock measurable growth.', 'mahadeva-ai' ); ?></p>
				</div>
				<div class="pricing-toggle" id="pricing-toggle">
					<span class="active" data-cycle="monthly"><?php esc_html_e( 'Billed Monthly', 'mahadeva-ai' ); ?></span>
					<button class="switch" type="button" aria-label="<?php esc_attr_e( 'Toggle billing cycle', 'mahadeva-ai' ); ?>"></button>
					<span data-cycle="yearly"><?php esc_html_e( 'Billed Yearly', 'mahadeva-ai' ); ?></span>
				</div>
				<div class="pricing-grid">
					<?php
					while ( $plans->have_posts() ) : $plans->the_post();
						mahadeva_pricing_card( get_the_ID() );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<!-- FAQ -->
	<?php
	$faqs = new WP_Query( array( 'post_type' => 'faq_item', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $faqs->have_posts() ) :
		?>
		<section class="section">
			<div class="container">
				<div class="section-head center">
					<h2 class="headline"><?php esc_html_e( 'Answers to Your Questions', 'mahadeva-ai' ); ?></h2>
					<p class="lede" style="margin-inline:auto;"><?php esc_html_e( 'Find clear answers about how our AI systems work and how they help teams grow faster together.', 'mahadeva-ai' ); ?></p>
				</div>
				<div class="faq-list">
					<?php
					while ( $faqs->have_posts() ) : $faqs->the_post();
						?>
						<details class="faq-item">
							<summary><?php the_title(); ?><span class="plus"></span></summary>
							<div class="faq-a"><?php the_content(); ?></div>
						</details>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

</main>

<?php get_footer(); ?>
