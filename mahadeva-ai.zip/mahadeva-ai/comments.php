<?php
/**
 * Comments template.
 *
 * @package Mahadeva_AI
 */

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-area">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			printf(
				/* translators: %s: comment count. */
				esc_html( _nx( '%s Comment', '%s Comments', get_comments_number(), 'comments title', 'mahadeva-ai' ) ),
				esc_html( number_format_i18n( get_comments_number() ) )
			);
			?>
		</h2>
		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'    => 'ol',
				'callback' => 'mahadeva_comment_cb',
			) );
			?>
		</ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p><?php esc_html_e( 'Comments are closed.', 'mahadeva-ai' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_form'   => 'comment-form',
		'title_reply'  => __( 'Leave a Comment', 'mahadeva-ai' ),
		'label_submit' => __( 'Post Comment', 'mahadeva-ai' ),
	) );
	?>
</div>
