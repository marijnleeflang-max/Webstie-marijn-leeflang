<?php
/**
 * Search form template.
 *
 * @package Mahadeva_AI
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:flex;gap:.6rem;">
	<label class="screen-reader-text" for="s"><?php esc_html_e( 'Search for:', 'mahadeva-ai' ); ?></label>
	<input type="search" id="s" name="s" placeholder="<?php esc_attr_e( 'Search…', 'mahadeva-ai' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" style="flex:1;background:var(--bg-alt);border:1px solid var(--line);color:var(--ink);padding:.8rem 1rem;">
	<button type="submit" class="btn btn-outline btn-sm"><?php esc_html_e( 'Search', 'mahadeva-ai' ); ?></button>
</form>
