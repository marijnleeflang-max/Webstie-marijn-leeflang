<?php
/**
 * 404 template.
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container error-404">
		<p class="big">404</p>
		<h1><?php esc_html_e( 'This page automated itself away.', 'mahadeva-ai' ); ?></h1>
		<p class="lede" style="margin-inline:auto;"><?php esc_html_e( 'The page you are looking for does not exist or has moved.', 'mahadeva-ai' ); ?></p>
		<div class="hero-actions">
			<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Home', 'mahadeva-ai' ); ?></a>
		</div>
		<div style="max-width:420px;margin:3rem auto 0;"><?php get_search_form(); ?></div>
	</div>
</main>
<?php get_footer(); ?>
