<?php
/**
 * Customizer settings.
 *
 * @package Mahadeva_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mahadeva_customize_register( $wp_customize ) {

	/* ---------- Hero ---------- */
	$wp_customize->add_section( 'mahadeva_hero', array(
		'title'    => __( 'Hero Section', 'mahadeva-ai' ),
		'priority' => 30,
	) );

	$wp_customize->add_setting( 'hero_tag', array( 'default' => __( 'AI Automation Studio', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hero_tag', array( 'label' => __( 'Hero eyebrow tag', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'text' ) );

	$wp_customize->add_setting( 'hero_heading', array( 'default' => __( 'Custom AI Solutions to Increase Revenue', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hero_heading', array( 'label' => __( 'Hero heading', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'textarea' ) );

	$wp_customize->add_setting( 'hero_heading_accent', array( 'default' => __( 'Increase Revenue', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hero_heading_accent', array( 'label' => __( 'Portion of heading to highlight with gradient', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'text' ) );

	$wp_customize->add_setting( 'hero_subheading', array( 'default' => __( 'We build intelligent systems that automate decisions, boost productivity, and drive scalable growth for modern teams.', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'hero_subheading', array( 'label' => __( 'Hero subheading', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'textarea' ) );

	$wp_customize->add_setting( 'hero_btn1_text', array( 'default' => __( 'Get Free Consultation', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hero_btn1_text', array( 'label' => __( 'Primary button text', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'text' ) );

	$wp_customize->add_setting( 'hero_btn1_url', array( 'default' => '#contact', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'hero_btn1_url', array( 'label' => __( 'Primary button URL', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'url' ) );

	$wp_customize->add_setting( 'hero_btn2_text', array( 'default' => __( 'Explore Our Work', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hero_btn2_text', array( 'label' => __( 'Secondary button text', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'text' ) );

	$wp_customize->add_setting( 'hero_btn2_url', array( 'default' => '#work', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'hero_btn2_url', array( 'label' => __( 'Secondary button URL', 'mahadeva-ai' ), 'section' => 'mahadeva_hero', 'type' => 'url' ) );

	/* ---------- Statement ---------- */
	$wp_customize->add_section( 'mahadeva_statement', array(
		'title'    => __( 'About / Statement Section', 'mahadeva-ai' ),
		'priority' => 31,
	) );
	$wp_customize->add_setting( 'statement_eyebrow', array( 'default' => __( 'AI First Agency', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'statement_eyebrow', array( 'label' => __( 'Eyebrow', 'mahadeva-ai' ), 'section' => 'mahadeva_statement', 'type' => 'text' ) );
	$wp_customize->add_setting( 'statement_text', array( 'default' => __( 'Mahadeva helps ambitious brands transform AI into practical systems that automate work, boost efficiency, and drive measurable growth across teams.', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'statement_text', array( 'label' => __( 'Statement text', 'mahadeva-ai' ), 'section' => 'mahadeva_statement', 'type' => 'textarea' ) );

	/* ---------- Stats (4) ---------- */
	$wp_customize->add_section( 'mahadeva_stats', array(
		'title'    => __( 'Trust Stats (4)', 'mahadeva-ai' ),
		'priority' => 32,
	) );
	$stat_defaults = array(
		1 => array( 'fig' => '98%', 'label' => 'Launch Success', 'desc' => 'Solutions successfully adopted by teams to deliver consistent performance at scale.' ),
		2 => array( 'fig' => '3X', 'label' => 'Average ROI', 'desc' => 'Systems designed to increase revenue efficiency and scalable business growth.' ),
		3 => array( 'fig' => '120H', 'label' => 'Faster Operations', 'desc' => 'Hours saved every month through automation and reduced manual work.' ),
		4 => array( 'fig' => '$1M', 'label' => 'Revenue Impact', 'desc' => 'Automation built to increase revenue and drive measurable business growth.' ),
	);
	foreach ( $stat_defaults as $i => $d ) {
		foreach ( array( 'fig', 'label', 'desc' ) as $f ) {
			$key = "stat_{$i}_{$f}";
			$wp_customize->add_setting( $key, array( 'default' => $d[ $f ], 'sanitize_callback' => 'sanitize_text_field' ) );
			$wp_customize->add_control( $key, array( 'label' => sprintf( __( 'Stat %1$d — %2$s', 'mahadeva-ai' ), $i, ucfirst( $f ) ), 'section' => 'mahadeva_stats', 'type' => 'text' ) );
		}
	}

	/* ---------- CTA banner ---------- */
	$wp_customize->add_section( 'mahadeva_cta', array(
		'title'    => __( 'CTA Banner', 'mahadeva-ai' ),
		'priority' => 33,
	) );
	$wp_customize->add_setting( 'cta_heading', array( 'default' => __( 'Ready to Build Your AI Growth Engine?', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'cta_heading', array( 'label' => __( 'Heading', 'mahadeva-ai' ), 'section' => 'mahadeva_cta', 'type' => 'text' ) );
	$wp_customize->add_setting( 'cta_btn_text', array( 'default' => __( 'Get Free Consultation', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'cta_btn_text', array( 'label' => __( 'Button text', 'mahadeva-ai' ), 'section' => 'mahadeva_cta', 'type' => 'text' ) );
	$wp_customize->add_setting( 'cta_btn_url', array( 'default' => '#contact', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'cta_btn_url', array( 'label' => __( 'Button URL', 'mahadeva-ai' ), 'section' => 'mahadeva_cta', 'type' => 'url' ) );

	/* ---------- Contact & Social ---------- */
	$wp_customize->add_section( 'mahadeva_contact', array(
		'title'    => __( 'Contact & Social', 'mahadeva-ai' ),
		'priority' => 34,
	) );
	$contact_fields = array(
		'contact_email'    => array( __( 'Email', 'mahadeva-ai' ), 'info@example.com', 'sanitize_email' ),
		'contact_phone'    => array( __( 'Phone', 'mahadeva-ai' ), '+1 (960) 258 8964', 'sanitize_text_field' ),
		'social_linkedin'  => array( __( 'LinkedIn URL', 'mahadeva-ai' ), '', 'esc_url_raw' ),
		'social_instagram' => array( __( 'Instagram URL', 'mahadeva-ai' ), '', 'esc_url_raw' ),
		'social_twitter'   => array( __( 'X / Twitter URL', 'mahadeva-ai' ), '', 'esc_url_raw' ),
	);
	foreach ( $contact_fields as $key => $d ) {
		$wp_customize->add_setting( $key, array( 'default' => $d[1], 'sanitize_callback' => $d[2] ) );
		$wp_customize->add_control( $key, array( 'label' => $d[0], 'section' => 'mahadeva_contact', 'type' => 'text' ) );
	}

	/* ---------- Footer ---------- */
	$wp_customize->add_section( 'mahadeva_footer', array(
		'title'    => __( 'Footer', 'mahadeva-ai' ),
		'priority' => 35,
	) );
	$wp_customize->add_setting( 'footer_about', array( 'default' => __( 'We build intelligent systems that automate decisions and drive scalable growth for modern teams.', 'mahadeva-ai' ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'footer_about', array( 'label' => __( 'Short about text', 'mahadeva-ai' ), 'section' => 'mahadeva_footer', 'type' => 'textarea' ) );
	$wp_customize->add_setting( 'footer_copyright', array( 'default' => sprintf( __( '© %s Mahadeva. All Rights Reserved.', 'mahadeva-ai' ), gmdate( 'Y' ) ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'footer_copyright', array( 'label' => __( 'Copyright line', 'mahadeva-ai' ), 'section' => 'mahadeva_footer', 'type' => 'text' ) );
}
add_action( 'customize_register', 'mahadeva_customize_register' );
