<?php
/**
 * Custom Post Types + Meta Boxes.
 *
 * @package Mahadeva_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register CPTs.
 */
function mahadeva_register_cpts() {

	register_post_type( 'case_study', array(
		'labels' => array(
			'name'          => __( 'Case Studies', 'mahadeva-ai' ),
			'singular_name' => __( 'Case Study', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Case Study', 'mahadeva-ai' ),
		),
		'public'       => true,
		'has_archive'  => true,
		'rewrite'      => array( 'slug' => 'case-study' ),
		'menu_icon'    => 'dashicons-chart-line',
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'testimonial', array(
		'labels' => array(
			'name'          => __( 'Testimonials', 'mahadeva-ai' ),
			'singular_name' => __( 'Testimonial', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Testimonial', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-format-quote',
		'supports'     => array( 'title', 'editor', 'thumbnail' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'pricing_plan', array(
		'labels' => array(
			'name'          => __( 'Pricing Plans', 'mahadeva-ai' ),
			'singular_name' => __( 'Pricing Plan', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Plan', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-tag',
		'supports'     => array( 'title', 'editor', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'faq_item', array(
		'labels' => array(
			'name'          => __( 'FAQs', 'mahadeva-ai' ),
			'singular_name' => __( 'FAQ', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New FAQ', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-editor-help',
		'supports'     => array( 'title', 'editor', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'team_member', array(
		'labels' => array(
			'name'          => __( 'Team Members', 'mahadeva-ai' ),
			'singular_name' => __( 'Team Member', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Team Member', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-groups',
		'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'job_opening', array(
		'labels' => array(
			'name'          => __( 'Job Openings', 'mahadeva-ai' ),
			'singular_name' => __( 'Job Opening', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Job', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-businessman',
		'supports'     => array( 'title', 'editor' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'tech_tool', array(
		'labels' => array(
			'name'          => __( 'Tech Stack', 'mahadeva-ai' ),
			'singular_name' => __( 'Tech Tool', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Tool', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-admin-plugins',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_post_type( 'client_logo', array(
		'labels' => array(
			'name'          => __( 'Client Logos', 'mahadeva-ai' ),
			'singular_name' => __( 'Client Logo', 'mahadeva-ai' ),
			'add_new_item'  => __( 'Add New Logo', 'mahadeva-ai' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-images-alt2',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
		'show_in_rest' => true,
	) );
}
add_action( 'init', 'mahadeva_register_cpts' );

/**
 * Meta boxes.
 */
function mahadeva_add_meta_boxes() {
	add_meta_box( 'mahadeva_case_meta', __( 'Case Study Details', 'mahadeva-ai' ), 'mahadeva_case_meta_cb', 'case_study', 'normal', 'high' );
	add_meta_box( 'mahadeva_testi_meta', __( 'Testimonial Details', 'mahadeva-ai' ), 'mahadeva_testi_meta_cb', 'testimonial', 'normal', 'high' );
	add_meta_box( 'mahadeva_price_meta', __( 'Plan Details', 'mahadeva-ai' ), 'mahadeva_price_meta_cb', 'pricing_plan', 'normal', 'high' );
	add_meta_box( 'mahadeva_team_meta', __( 'Role', 'mahadeva-ai' ), 'mahadeva_team_meta_cb', 'team_member', 'normal', 'high' );
	add_meta_box( 'mahadeva_job_meta', __( 'Job Details', 'mahadeva-ai' ), 'mahadeva_job_meta_cb', 'job_opening', 'normal', 'high' );
	add_meta_box( 'mahadeva_logo_meta', __( 'Link', 'mahadeva-ai' ), 'mahadeva_logo_meta_cb', 'client_logo', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'mahadeva_add_meta_boxes' );

function mahadeva_field_row( $post, $key, $label, $type = 'text' ) {
	$value = get_post_meta( $post->ID, $key, true );
	echo '<p><label style="display:block;font-weight:600;margin-bottom:4px;" for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label>';
	if ( 'textarea' === $type ) {
		echo '<textarea style="width:100%;min-height:90px;" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
	} elseif ( 'checkbox' === $type ) {
		echo '<input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( $value, '1', false ) . ' />';
	} else {
		echo '<input type="text" style="width:100%;" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
	}
	echo '</p>';
}

function mahadeva_case_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'case_year', __( 'Year', 'mahadeva-ai' ) );
	echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 20px;">';
	for ( $i = 1; $i <= 4; $i++ ) {
		mahadeva_field_row( $post, "metric_{$i}_label", sprintf( __( 'Metric %d Label', 'mahadeva-ai' ), $i ) );
		mahadeva_field_row( $post, "metric_{$i}_value", sprintf( __( 'Metric %d Value', 'mahadeva-ai' ), $i ) );
	}
	echo '</div>';
}

function mahadeva_testi_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'author_name', __( 'Author Name', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'author_role', __( 'Author Role @ Company', 'mahadeva-ai' ) );
}

function mahadeva_price_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'plan_price', __( 'Price (number only, e.g. 199)', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'plan_price_yearly', __( 'Yearly Price (number only)', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'plan_period', __( 'Period label (e.g. /month, or "Custom Quote")', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'plan_button_text', __( 'Button Text', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'plan_button_url', __( 'Button URL', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'plan_featured', __( 'Featured / Most Popular', 'mahadeva-ai' ), 'checkbox' );
	mahadeva_field_row( $post, 'plan_features', __( 'Includes (one per line)', 'mahadeva-ai' ), 'textarea' );
}

function mahadeva_team_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'member_role', __( 'Role / Title', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'member_linkedin', __( 'LinkedIn URL', 'mahadeva-ai' ) );
}

function mahadeva_job_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'job_location', __( 'Location (e.g. Remote)', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'job_type', __( 'Type (e.g. Full-time)', 'mahadeva-ai' ) );
	mahadeva_field_row( $post, 'job_apply_url', __( 'Apply URL', 'mahadeva-ai' ) );
}

function mahadeva_logo_meta_cb( $post ) {
	wp_nonce_field( 'mahadeva_save_meta', 'mahadeva_meta_nonce' );
	mahadeva_field_row( $post, 'logo_url', __( 'Link URL (optional)', 'mahadeva-ai' ) );
}

function mahadeva_save_meta( $post_id ) {
	if ( ! isset( $_POST['mahadeva_meta_nonce'] ) || ! wp_verify_nonce( $_POST['mahadeva_meta_nonce'], 'mahadeva_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'case_year', 'metric_1_label', 'metric_1_value', 'metric_2_label', 'metric_2_value',
		'metric_3_label', 'metric_3_value', 'metric_4_label', 'metric_4_value',
		'author_name', 'author_role',
		'plan_price', 'plan_price_yearly', 'plan_period', 'plan_button_text', 'plan_button_url', 'plan_featured', 'plan_features',
		'member_role', 'member_linkedin',
		'job_location', 'job_type', 'job_apply_url',
		'logo_url',
	);

	foreach ( $fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			$value = 'plan_features' === $field ? sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
			update_post_meta( $post_id, $field, $value );
		} elseif ( 'plan_featured' === $field ) {
			delete_post_meta( $post_id, $field );
		}
	}
}
add_action( 'save_post', 'mahadeva_save_meta' );
