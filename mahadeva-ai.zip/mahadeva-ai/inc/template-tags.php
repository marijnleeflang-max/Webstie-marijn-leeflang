<?php
/**
 * Template tags / helper functions.
 *
 * @package Mahadeva_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post meta line: date + author, used on blog cards and single posts.
 */
function mahadeva_posted_on() {
	printf(
		'<span class="posted-on">%1$s</span> <span class="byline">%2$s %3$s</span>',
		esc_html( get_the_date() ),
		esc_html__( 'by', 'mahadeva-ai' ),
		esc_html( get_the_author() )
	);
}

/**
 * Numeric pagination for archives.
 */
function mahadeva_pagination() {
	the_posts_pagination( array(
		'mid_size'  => 1,
		'prev_text' => __( '&larr;', 'mahadeva-ai' ),
		'next_text' => __( '&rarr;', 'mahadeva-ai' ),
	) );
}

/**
 * Comment callback for wp_list_comments().
 */
function mahadeva_comment_cb( $comment, $args, $depth ) {
	?>
	<li <?php comment_class( 'comment-body' ); ?> id="comment-<?php comment_ID(); ?>">
		<div class="comment-meta">
			<?php echo get_avatar( $comment, 44 ); ?>
			<strong><?php comment_author(); ?></strong> &middot; <?php comment_date(); ?>
		</div>
		<div class="comment-content"><?php comment_text(); ?></div>
		<?php
		comment_reply_link( array_merge( $args, array(
			'depth'     => $depth,
			'max_depth' => $args['max_depth'],
			'reply_text' => __( 'Reply', 'mahadeva-ai' ),
		) ) );
		?>
	</li>
	<?php
}

/**
 * Render a case study card (used on front page + archive).
 */
function mahadeva_case_card( $post_id ) {
	$year = get_post_meta( $post_id, 'case_year', true );
	?>
	<a class="case-card" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>">
		<div class="thumb">
			<?php echo get_the_post_thumbnail( $post_id, 'medium_large' ); ?>
		</div>
		<div class="body">
			<?php if ( $year ) : ?><span class="year"><?php echo esc_html( $year ); ?></span><?php endif; ?>
			<h3><?php echo esc_html( get_the_title( $post_id ) ); ?></h3>
			<p><?php echo esc_html( wp_trim_words( get_the_excerpt( $post_id ), 16 ) ); ?></p>
			<div class="metrics">
				<?php for ( $i = 1; $i <= 2; $i++ ) :
					$label = get_post_meta( $post_id, "metric_{$i}_label", true );
					$value = get_post_meta( $post_id, "metric_{$i}_value", true );
					if ( ! $value ) { continue; }
					?>
					<div><?php echo esc_html( $value ); ?><span><?php echo esc_html( $label ); ?></span></div>
				<?php endfor; ?>
			</div>
		</div>
	</a>
	<?php
}

/**
 * Render a pricing card.
 */
function mahadeva_pricing_card( $post_id ) {
	$price_m  = get_post_meta( $post_id, 'plan_price', true );
	$price_y  = get_post_meta( $post_id, 'plan_price_yearly', true );
	$period   = get_post_meta( $post_id, 'plan_period', true );
	$btn_text = get_post_meta( $post_id, 'plan_button_text', true ) ?: __( 'Choose Plan', 'mahadeva-ai' );
	$btn_url  = get_post_meta( $post_id, 'plan_button_url', true ) ?: '#contact';
	$featured = get_post_meta( $post_id, 'plan_featured', true );
	$features = array_filter( array_map( 'trim', explode( "\n", get_post_meta( $post_id, 'plan_features', true ) ) ) );
	$is_custom = ( ! is_numeric( $price_m ) || '' === $price_m );
	?>
	<div class="price-card<?php echo $featured ? ' featured' : ''; ?>">
		<div class="icon"><?php echo mahadeva_icon( 'bolt' ); ?></div>
		<h3><?php echo esc_html( get_the_title( $post_id ) ); ?></h3>
		<?php if ( $is_custom ) : ?>
			<div class="amount"><span class="num" style="font-size:1.8rem;"><?php echo esc_html( $price_m ? $price_m : __( 'Custom Quote', 'mahadeva-ai' ) ); ?></span></div>
		<?php else : ?>
			<div class="amount" data-monthly="<?php echo esc_attr( $price_m ); ?>" data-yearly="<?php echo esc_attr( $price_y ?: $price_m ); ?>">
				<span class="cur">$</span><span class="num price-num"><?php echo esc_html( $price_m ); ?></span><span class="per"><?php echo esc_html( $period ?: '/month' ); ?></span>
			</div>
		<?php endif; ?>
		<p><?php echo esc_html( get_the_excerpt( $post_id ) ); ?></p>
		<a class="btn <?php echo $featured ? 'btn-grad' : 'btn-outline'; ?>" href="<?php echo esc_url( $btn_url ); ?>"><?php echo esc_html( $btn_text ); ?></a>
		<?php if ( $features ) : ?>
			<div class="includes-label"><?php esc_html_e( 'Includes', 'mahadeva-ai' ); ?></div>
			<ul>
				<?php foreach ( $features as $f ) : ?><li><?php echo esc_html( $f ); ?></li><?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
}
