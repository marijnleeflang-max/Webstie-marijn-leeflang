<?php
/**
 * Seed sample content on first activation only (never overwrites existing content).
 *
 * @package Mahadeva_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mahadeva_seed_content() {
	if ( get_option( 'mahadeva_seeded' ) ) {
		return;
	}

	// Case studies.
	$cases = array(
		array( 'title' => 'AI Agent Website Built for Automation Startups', 'year' => '2023', 'excerpt' => 'AI-driven automation systems improved engagement and conversion clarity for a SaaS company.', 'm' => array( 'Demo Click Growth' => '13.2x', 'Pipeline Influence' => '$80K+', 'Higher Engagement' => '42%', 'Qualified Leads' => '77%' ) ),
		array( 'title' => 'Digital Wallet & Finance Website For Banks', 'year' => '2025', 'excerpt' => 'Built for modern fintech brands to establish trust and simplify complex messaging.', 'm' => array( 'User Interaction' => '10x', 'Revenue Opportunity' => '$1M+', 'Increase in Signals' => '42%', 'New Signups' => '78+' ) ),
		array( 'title' => 'Minimal Blog & Editorial Website for Publishers', 'year' => '2023', 'excerpt' => 'Created for content-driven brands that need clean layouts and better readability.', 'm' => array( 'Read Engagement' => '21x', 'Content Growth' => '$90K+', 'Lower Exit Rate' => '35%', 'Published Articles' => '38+' ) ),
	);
	foreach ( $cases as $c ) {
		$id = wp_insert_post( array(
			'post_type'    => 'case_study',
			'post_title'   => $c['title'],
			'post_excerpt' => $c['excerpt'],
			'post_content' => '<p>' . $c['excerpt'] . '</p>',
			'post_status'  => 'publish',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'case_year', $c['year'] );
			$i = 1;
			foreach ( $c['m'] as $label => $value ) {
				update_post_meta( $id, "metric_{$i}_label", $label );
				update_post_meta( $id, "metric_{$i}_value", $value );
				$i++;
			}
		}
	}

	// Testimonials.
	$testis = array(
		array( 'quote' => 'This system saved our team hours every week and made our workflows faster, clearer, and much easier to manage.', 'name' => 'Ryan Mitchell', 'role' => 'CEO @ Growth SaaS' ),
		array( 'quote' => 'Automation finally feels simple for our team, helping us move faster while staying focused on real goals.', 'name' => 'Isabella Reed', 'role' => 'Operations Lead @ Coreflux AI' ),
		array( 'quote' => 'We started seeing improvements within weeks, and the workflow now feels smooth and easier to manage.', 'name' => 'Lisa Parker', 'role' => 'Sales Director @ Nexora AI Labs' ),
	);
	foreach ( $testis as $t ) {
		$id = wp_insert_post( array(
			'post_type'    => 'testimonial',
			'post_title'   => $t['name'],
			'post_content' => $t['quote'],
			'post_status'  => 'publish',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'author_name', $t['name'] );
			update_post_meta( $id, 'author_role', $t['role'] );
		}
	}

	// Pricing plans.
	$plans = array(
		array( 'title' => 'Launch', 'excerpt' => 'Designed to help early-stage teams streamline workflows and reduce manual effort.', 'price' => '199', 'price_y' => '1990', 'feat' => array( 'AI workflow audit', 'Core automation setup', 'Tool integration support', 'Single workflow system', 'Performance dashboard' ), 'featured' => false ),
		array( 'title' => 'Scale', 'excerpt' => 'Advanced automation systems designed to improve efficiency and accelerate growth.', 'price' => '299', 'price_y' => '2990', 'feat' => array( 'Multiple workflows', 'Custom AI agents', 'Full integrations', 'Optimization cycles', 'Priority support' ), 'featured' => true ),
		array( 'title' => 'Enterprise', 'excerpt' => 'Fully customized automation infrastructure for complex, long-term transformation.', 'price' => '', 'price_y' => '', 'feat' => array( 'Strategy workshops', 'Unlimited workflows', 'Advanced AI systems', 'Custom automations', 'Enterprise integrations', 'Dedicated team support' ), 'featured' => false ),
	);
	$order = 0;
	foreach ( $plans as $p ) {
		$id = wp_insert_post( array(
			'post_type'    => 'pricing_plan',
			'post_title'   => $p['title'],
			'post_excerpt' => $p['excerpt'],
			'post_status'  => 'publish',
			'menu_order'   => $order++,
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'plan_price', $p['price'] );
			update_post_meta( $id, 'plan_price_yearly', $p['price_y'] );
			update_post_meta( $id, 'plan_period', $p['price'] ? '/month' : 'Custom Quote' );
			update_post_meta( $id, 'plan_button_text', $p['price'] ? 'Choose ' . $p['title'] : 'Request a Quote' );
			update_post_meta( $id, 'plan_button_url', '#contact' );
			update_post_meta( $id, 'plan_features', implode( "\n", $p['feat'] ) );
			if ( $p['featured'] ) {
				update_post_meta( $id, 'plan_featured', '1' );
			}
		}
	}

	// FAQs.
	$faqs = array(
		array( 'q' => 'What industries do you specialize in?', 'a' => 'We work with SaaS, ecommerce, agencies, finance, and fast-growing digital-first businesses globally.' ),
		array( 'q' => 'Are solutions customized for each client?', 'a' => 'Every system is custom built to match workflows, goals, and team operational needs.' ),
		array( 'q' => 'Do we need an internal tech team?', 'a' => 'No technical expertise needed. We handle setup, deployment, and ongoing optimization.' ),
		array( 'q' => 'How long does setup usually take?', 'a' => 'Most projects launch within weeks, helping teams automate faster without delays.' ),
		array( 'q' => 'Can you integrate with our current tools?', 'a' => 'Integrations connect smoothly with your existing tools, keeping workflows efficient.' ),
		array( 'q' => 'What happens after launch?', 'a' => 'Support continues after launch to optimize performance and ensure long-term success.' ),
	);
	$order = 0;
	foreach ( $faqs as $f ) {
		wp_insert_post( array(
			'post_type'    => 'faq_item',
			'post_title'   => $f['q'],
			'post_content' => $f['a'],
			'post_status'  => 'publish',
			'menu_order'   => $order++,
		) );
	}

	// Tech stack.
	$tools = array( 'Claude Code', 'OpenAI', 'Airtable', 'Zapier', 'LangChain', 'Python' );
	$order = 0;
	foreach ( $tools as $tool ) {
		wp_insert_post( array(
			'post_type'   => 'tech_tool',
			'post_title'  => $tool,
			'post_status' => 'publish',
			'menu_order'  => $order++,
		) );
	}

	update_option( 'mahadeva_seeded', 1 );
}
add_action( 'after_switch_theme', 'mahadeva_seed_content' );
