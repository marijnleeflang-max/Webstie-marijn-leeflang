<?php
/**
 * Footer template.
 *
 * @package Mahadeva_AI
 */
?>

	<section class="cta-banner" id="contact">
		<h2><?php echo esc_html( get_theme_mod( 'cta_heading', __( 'Ready to Build Your AI Growth Engine?', 'mahadeva-ai' ) ) ); ?></h2>
		<a class="btn btn-primary" href="<?php echo esc_url( get_theme_mod( 'cta_btn_url', '#contact' ) ); ?>"><?php echo esc_html( get_theme_mod( 'cta_btn_text', __( 'Get Free Consultation', 'mahadeva-ai' ) ) ); ?></a>
	</section>

	<footer id="colophon" class="site-footer">
		<div class="container">
			<div class="footer-grid">
				<div class="footer-brand">
					<p class="site-title"><span class="dot"></span><?php bloginfo( 'name' ); ?></p>
					<p><?php echo esc_html( get_theme_mod( 'footer_about', __( 'We build intelligent systems that automate decisions and drive scalable growth for modern teams.', 'mahadeva-ai' ) ) ); ?></p>
				</div>

				<div class="footer-col">
					<h5><?php esc_html_e( 'Navigation', 'mahadeva-ai' ); ?></h5>
					<?php
					if ( has_nav_menu( 'footer-navigation' ) ) {
						wp_nav_menu( array( 'theme_location' => 'footer-navigation', 'container' => false, 'menu_class' => '' ) );
					} else {
						echo '<ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'mahadeva-ai' ) . '</a></li></ul>';
					}
					?>
				</div>

				<div class="footer-col">
					<h5><?php esc_html_e( 'Company', 'mahadeva-ai' ); ?></h5>
					<?php
					if ( has_nav_menu( 'footer-company' ) ) {
						wp_nav_menu( array( 'theme_location' => 'footer-company', 'container' => false, 'menu_class' => '' ) );
					} else {
						echo '<ul><li><a href="' . esc_url( home_url( '/about' ) ) . '">' . esc_html__( 'About', 'mahadeva-ai' ) . '</a></li></ul>';
					}
					?>
				</div>

				<div class="footer-col">
					<h5><?php esc_html_e( 'Contact', 'mahadeva-ai' ); ?></h5>
					<ul>
						<?php $email = get_theme_mod( 'contact_email' ); ?>
						<?php if ( $email ) : ?><li><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></li><?php endif; ?>
						<?php $phone = get_theme_mod( 'contact_phone' ); ?>
						<?php if ( $phone ) : ?><li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></li><?php endif; ?>
					</ul>
				</div>
			</div>

			<div class="footer-bottom">
				<p><?php echo esc_html( get_theme_mod( 'footer_copyright', sprintf( __( '© %s Mahadeva. All Rights Reserved.', 'mahadeva-ai' ), gmdate( 'Y' ) ) ) ); ?></p>
				<div class="footer-social">
					<?php
					$socials = array(
						'social_linkedin'  => 'LinkedIn',
						'social_instagram' => 'Instagram',
						'social_twitter'   => 'X / Twitter',
					);
					foreach ( $socials as $mod => $label ) {
						$url = get_theme_mod( $mod );
						if ( $url ) {
							echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $label ) . '</a>';
						}
					}
					?>
				</div>
			</div>
		</div>
	</footer>
<?php wp_footer(); ?>
</body>
</html>
