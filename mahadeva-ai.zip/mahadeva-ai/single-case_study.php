<?php
/**
 * Single Case Study template.
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'single-article' ); ?>>
				<header class="entry-header">
					<p class="entry-meta"><?php echo esc_html( get_post_meta( get_the_ID(), 'case_year', true ) ); ?></p>
					<h1><?php the_title(); ?></h1>
					<p class="lede" style="margin-inline:auto;"><?php the_excerpt(); ?></p>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-thumb"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>

				<div class="stats-grid" style="margin-bottom:3rem;">
					<?php for ( $i = 1; $i <= 4; $i++ ) :
						$label = get_post_meta( get_the_ID(), "metric_{$i}_label", true );
						$value = get_post_meta( get_the_ID(), "metric_{$i}_value", true );
						if ( ! $value ) { continue; }
						?>
						<div class="stat">
							<div class="fig" style="font-size:2rem;"><?php echo esc_html( $value ); ?></div>
							<h4><?php echo esc_html( $label ); ?></h4>
						</div>
					<?php endfor; ?>
				</div>

				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
		<?php endwhile; ?>

		<div class="text-center" style="margin-top:3rem;">
			<a class="btn btn-outline" href="<?php echo esc_url( get_post_type_archive_link( 'case_study' ) ); ?>">&larr; <?php esc_html_e( 'All Case Studies', 'mahadeva-ai' ); ?></a>
		</div>
	</div>
</main>
<?php get_footer(); ?>
