/**
 * Mahadeva AI theme front-end behavior.
 * Vanilla JS, no dependencies.
 */
( function () {
	'use strict';

	/* Mobile nav toggle */
	var header = document.getElementById( 'masthead' );
	var toggle = header ? header.querySelector( '.menu-toggle' ) : null;
	if ( header && toggle ) {
		toggle.addEventListener( 'click', function () {
			var isOpen = header.classList.toggle( 'nav-open' );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );

		// Close menu when a nav link is clicked (mobile).
		header.querySelectorAll( '.primary-nav a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function () {
				header.classList.remove( 'nav-open' );
				toggle.setAttribute( 'aria-expanded', 'false' );
			} );
		} );
	}

	/* FAQ accordion: only one <details> open at a time within the same list */
	document.querySelectorAll( '.faq-list' ).forEach( function ( list ) {
		var items = list.querySelectorAll( '.faq-item' );
		items.forEach( function ( item ) {
			item.addEventListener( 'toggle', function () {
				if ( item.open ) {
					items.forEach( function ( other ) {
						if ( other !== item ) {
							other.open = false;
						}
					} );
				}
			} );
		} );
	} );

	/* Pricing monthly / yearly toggle */
	document.querySelectorAll( '#pricing-toggle' ).forEach( function ( toggleWrap ) {
		var btn = toggleWrap.querySelector( '.switch' );
		var labels = toggleWrap.querySelectorAll( 'span[data-cycle]' );
		if ( ! btn ) {
			return;
		}
		btn.addEventListener( 'click', function () {
			var toYearly = ! btn.classList.contains( 'on' );
			btn.classList.toggle( 'on', toYearly );

			labels.forEach( function ( label ) {
				var match = ( label.getAttribute( 'data-cycle' ) === 'yearly' ) === toYearly;
				label.classList.toggle( 'active', match );
			} );

			document.querySelectorAll( '.price-card .amount[data-monthly]' ).forEach( function ( amount ) {
				var numEl = amount.querySelector( '.price-num' );
				if ( ! numEl ) {
					return;
				}
				numEl.textContent = toYearly ? amount.getAttribute( 'data-yearly' ) : amount.getAttribute( 'data-monthly' );
			} );

			document.querySelectorAll( '.price-card .amount .per' ).forEach( function ( per ) {
				per.textContent = toYearly ? '/year' : '/month';
			} );
		} );
	} );
} )();
