<?php
/**
 * Single blog post template.
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'single-article' ); ?>>
				<header class="entry-header">
					<p class="entry-meta"><?php mahadeva_posted_on(); ?></p>
					<h1><?php the_title(); ?></h1>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-thumb"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>

				<div class="entry-content">
					<?php the_content(); ?>
				</div>

				<?php
				$tags = get_the_tags();
				if ( $tags ) :
					?>
					<div class="entry-tags">
						<?php foreach ( $tags as $tag ) : ?>
							<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>"><?php echo esc_html( $tag->name ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</article>

			<?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer(); ?>
