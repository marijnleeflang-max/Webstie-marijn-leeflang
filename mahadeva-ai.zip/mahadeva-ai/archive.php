<?php
/**
 * Generic archive template (categories, tags, dates, authors, and CPT archives).
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<div class="page-banner" style="padding-top:0;">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Archive', 'mahadeva-ai' ); ?></p>
			<h1><?php the_archive_title(); ?></h1>
			<?php the_archive_description( '<div class="lede">', '</div>' ); ?>
		</div>

		<?php if ( have_posts() ) : ?>
			<div class="blog-grid">
				<?php while ( have_posts() ) : the_post(); ?>
					<?php if ( 'case_study' === get_post_type() ) : ?>
						<?php mahadeva_case_card( get_the_ID() ); ?>
					<?php else : ?>
						<a class="post-card" href="<?php the_permalink(); ?>">
							<div class="thumb">
								<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'medium_large' ); endif; ?>
							</div>
							<div class="body">
								<span class="meta"><?php echo esc_html( get_the_date() ); ?></span>
								<h3><?php the_title(); ?></h3>
								<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 16 ) ); ?></p>
							</div>
						</a>
					<?php endif; ?>
				<?php endwhile; ?>
			</div>
			<?php mahadeva_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Nothing found.', 'mahadeva-ai' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
