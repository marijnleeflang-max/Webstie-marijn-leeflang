<?php
/**
 * Default fallback template (used for the blog index when no home.php exists).
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<div class="page-banner" style="padding-top:0;">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Blog', 'mahadeva-ai' ); ?></p>
			<h1><?php esc_html_e( 'Insights on AI & Automation', 'mahadeva-ai' ); ?></h1>
		</div>

		<?php if ( have_posts() ) : ?>
			<div class="blog-grid">
				<?php while ( have_posts() ) : the_post(); ?>
					<a class="post-card" href="<?php the_permalink(); ?>">
						<div class="thumb">
							<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'medium_large' ); endif; ?>
						</div>
						<div class="body">
							<span class="meta"><?php echo esc_html( get_the_date() ); ?></span>
							<h3><?php the_title(); ?></h3>
							<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 16 ) ); ?></p>
						</div>
					</a>
				<?php endwhile; ?>
			</div>
			<?php mahadeva_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'No posts found.', 'mahadeva-ai' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
