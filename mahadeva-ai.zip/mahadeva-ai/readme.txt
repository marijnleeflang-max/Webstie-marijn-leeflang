=== Mahadeva AI ===

A bold, motion-driven WordPress theme for AI agencies and automation studios,
inspired by the visual language of the Mahadeva Framer template
(https://mahadeva.framer.ai/): a dark canvas, a violet-to-coral gradient
accent, sharp hard-edged cards instead of soft shadow "SaaS cards," and a
small lime-green pixel motif standing in for the original's voxel/pixel
details.

== Installation ==

1. Zip the `mahadeva-ai` folder (if it isn't already) and upload it via
   Appearance > Themes > Add New > Upload Theme, or copy the folder into
   `wp-content/themes/`.
2. Activate the theme. On first activation the theme seeds a small set of
   sample content (3 case studies, 3 testimonials, 3 pricing plans, 6 FAQs,
   6 tech-stack tiles) so the front page isn't empty. This only happens once
   and never overwrites content you edit or add afterwards.
3. Go to Settings > Reading and set "Your homepage displays" to a static
   page, OR simply leave it on "latest posts" — the theme's `front-page.php`
   is used automatically for the site's front page once one is chosen, and
   falls back sensibly either way. Easiest path: Pages > Add New, title it
   "Home", publish it, then set it as the front page in Settings > Reading.
4. Build your menu: Appearance > Menus, create a menu, assign it to
   "Primary Menu" (and optionally "Footer Navigation" / "Footer Company").
5. Set your logo, site icon and colors under Appearance > Customize.
   Theme-specific panels are grouped there: Hero Section, About/Statement,
   Trust Stats, CTA Banner, Contact & Social, Footer.

== Content model ==

Everything editorial lives in custom post types (all visible in the WP
admin sidebar):

- Case Studies      -> case_study     (year + up to 4 metrics per entry)
- Testimonials       -> testimonial    (quote in the content field, author
                                          name/role in the meta box)
- Pricing Plans       -> pricing_plan   (monthly/yearly price, feature list,
                                          "Featured" checkbox for the
                                          highlighted plan)
- FAQs                -> faq_item       (question = title, answer = content)
- Team Members         -> team_member    (used on the About page template)
- Job Openings          -> job_opening    (used on the Careers page template)
- Tech Stack tiles       -> tech_tool      (title + featured image = logo)
- Client Logos            -> client_logo    (featured image, shown in the
                                          scrolling logo strip)

Standard Pages get extra layouts via Page Attributes > Template:

- About Page
- Pricing Page
- Case Studies Page
- Careers Page
- Contact Page

Blog posts use the normal Posts screen and `single.php` / `index.php` /
`archive.php`.

== Notes ==

- No page builder or third-party plugin is required; everything above is
  built with core WordPress APIs (custom post types, post meta, the
  Customizer, nav menus, widgets).
- The contact page template will auto-detect and use Contact Form 7 if
  that plugin is active; otherwise it shows a plain HTML fallback form
  (you'll need a form plugin or custom handler to receive submissions).
- Colors, type and spacing are all CSS custom properties at the top of
  style.css under "DESIGN TOKENS" — change them there to re-theme the
  whole site.
