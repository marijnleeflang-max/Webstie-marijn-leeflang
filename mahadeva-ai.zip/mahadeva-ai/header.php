<?php
/**
 * Header template.
 *
 * @package Mahadeva_AI
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#primary"><?php esc_html_e( 'Skip to content', 'mahadeva-ai' ); ?></a>

<header id="masthead" class="site-header">
	<div class="container">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<p class="site-title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<span class="dot"></span><?php bloginfo( 'name' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</div>

		<nav id="primary" class="primary-nav" aria-label="<?php esc_attr_e( 'Primary', 'mahadeva-ai' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => '',
				) );
			} else {
				mahadeva_fallback_menu();
			}
			?>
		</nav>

		<div class="header-cta">
			<a class="btn btn-primary btn-sm" href="<?php echo esc_url( get_theme_mod( 'hero_btn1_url', '#contact' ) ); ?>"><?php esc_html_e( 'Get Started', 'mahadeva-ai' ); ?></a>
			<button class="menu-toggle" aria-controls="primary" aria-expanded="false">
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'mahadeva-ai' ); ?></span>
				<span></span>
			</button>
		</div>
	</div>
</header>
