<?php
/**
 * Template Name: About Page
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="page-banner">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'About Us', 'mahadeva-ai' ); ?></p>
			<h1><?php the_title(); ?></h1>
		</div>

		<div class="container">
			<div class="page-content entry-content">
				<?php the_content(); ?>
			</div>
		</div>
	<?php endwhile; ?>

	<?php
	$team = new WP_Query( array( 'post_type' => 'team_member', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $team->have_posts() ) :
		?>
		<div class="container section" style="padding-top:0;">
			<div class="section-head center">
				<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Our Team', 'mahadeva-ai' ); ?></p>
				<h2 class="headline"><?php esc_html_e( 'The people behind the systems', 'mahadeva-ai' ); ?></h2>
			</div>
			<div class="team-grid">
				<?php while ( $team->have_posts() ) : $team->the_post(); ?>
					<div class="team-card">
						<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'medium' ); endif; ?>
						<h4><?php the_title(); ?></h4>
						<span><?php echo esc_html( get_post_meta( get_the_ID(), 'member_role', true ) ); ?></span>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		</div>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
