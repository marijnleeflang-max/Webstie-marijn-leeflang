<?php
/**
 * Template Name: Pricing Page
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="page-banner">
		<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Pricing', 'mahadeva-ai' ); ?></p>
		<h1><?php the_title(); ?></h1>
		<?php if ( get_the_content() ) : ?><div class="lede" style="margin-inline:auto;"><?php the_content(); ?></div><?php endif; ?>
	</div>

	<div class="container section" style="padding-top:0;">
		<div class="pricing-toggle" id="pricing-toggle">
			<span class="active" data-cycle="monthly"><?php esc_html_e( 'Billed Monthly', 'mahadeva-ai' ); ?></span>
			<button class="switch" type="button" aria-label="<?php esc_attr_e( 'Toggle billing cycle', 'mahadeva-ai' ); ?>"></button>
			<span data-cycle="yearly"><?php esc_html_e( 'Billed Yearly', 'mahadeva-ai' ); ?></span>
		</div>
		<div class="pricing-grid">
			<?php
			$plans = new WP_Query( array( 'post_type' => 'pricing_plan', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
			if ( $plans->have_posts() ) :
				while ( $plans->have_posts() ) : $plans->the_post();
					mahadeva_pricing_card( get_the_ID() );
				endwhile;
				wp_reset_postdata();
			else :
				echo '<p>' . esc_html__( 'Add Pricing Plans from the admin dashboard to populate this page.', 'mahadeva-ai' ) . '</p>';
			endif;
			?>
		</div>
	</div>

	<?php
	$faqs = new WP_Query( array( 'post_type' => 'faq_item', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $faqs->have_posts() ) :
		?>
		<div class="container section">
			<div class="section-head center">
				<h2 class="headline"><?php esc_html_e( 'Questions about pricing', 'mahadeva-ai' ); ?></h2>
			</div>
			<div class="faq-list">
				<?php while ( $faqs->have_posts() ) : $faqs->the_post(); ?>
					<details class="faq-item">
						<summary><?php the_title(); ?><span class="plus"></span></summary>
						<div class="faq-a"><?php the_content(); ?></div>
					</details>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		</div>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
