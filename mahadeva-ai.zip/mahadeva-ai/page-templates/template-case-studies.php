<?php
/**
 * Template Name: Case Studies Page
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="page-banner">
		<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Case Studies', 'mahadeva-ai' ); ?></p>
		<h1><?php the_title(); ?></h1>
	</div>

	<div class="container section" style="padding-top:0;">
		<div class="case-grid">
			<?php
			$cases = new WP_Query( array( 'post_type' => 'case_study', 'posts_per_page' => -1 ) );
			if ( $cases->have_posts() ) :
				while ( $cases->have_posts() ) : $cases->the_post();
					mahadeva_case_card( get_the_ID() );
				endwhile;
				wp_reset_postdata();
			else :
				echo '<p>' . esc_html__( 'Add Case Studies from the admin dashboard to populate this page.', 'mahadeva-ai' ) . '</p>';
			endif;
			?>
		</div>
	</div>
</main>
<?php get_footer(); ?>
