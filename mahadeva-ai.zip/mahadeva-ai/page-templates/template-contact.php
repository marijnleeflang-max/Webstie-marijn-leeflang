<?php
/**
 * Template Name: Contact Page
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="page-banner">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Contact', 'mahadeva-ai' ); ?></p>
			<h1><?php the_title(); ?></h1>
			<?php if ( get_the_content() ) : ?><div class="lede" style="margin-inline:auto;"><?php the_content(); ?></div><?php endif; ?>
		</div>
	<?php endwhile; ?>

	<div class="container section" style="padding-top:0;">
		<div class="contact-wrap">
			<div class="contact-info">
				<?php $email = get_theme_mod( 'contact_email' ); ?>
				<?php if ( $email ) : ?>
					<div class="item">
						<div class="ic"><?php echo mahadeva_icon( 'square' ); ?></div>
						<div>
							<h4><?php esc_html_e( 'Email', 'mahadeva-ai' ); ?></h4>
							<p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
						</div>
					</div>
				<?php endif; ?>
				<?php $phone = get_theme_mod( 'contact_phone' ); ?>
				<?php if ( $phone ) : ?>
					<div class="item">
						<div class="ic"><?php echo mahadeva_icon( 'square' ); ?></div>
						<div>
							<h4><?php esc_html_e( 'Phone', 'mahadeva-ai' ); ?></h4>
							<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<div class="contact-form">
				<?php
				if ( shortcode_exists( 'contact-form-7' ) ) {
					echo do_shortcode( '[contact-form-7 id="" title="Contact form"]' );
				} else {
					?>
					<form action="#" method="post">
						<label for="cf-name"><?php esc_html_e( 'Name', 'mahadeva-ai' ); ?></label>
						<input type="text" id="cf-name" name="cf-name" required>
						<label for="cf-email"><?php esc_html_e( 'Email', 'mahadeva-ai' ); ?></label>
						<input type="email" id="cf-email" name="cf-email" required>
						<label for="cf-message"><?php esc_html_e( 'Message', 'mahadeva-ai' ); ?></label>
						<textarea id="cf-message" name="cf-message" required></textarea>
						<button type="submit" class="btn btn-grad"><?php esc_html_e( 'Send Message', 'mahadeva-ai' ); ?></button>
						<p style="font-size:.75rem;color:var(--muted);margin-top:.8rem;"><?php esc_html_e( 'Connect a form plugin such as Contact Form 7 to make this form functional.', 'mahadeva-ai' ); ?></p>
					</form>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</main>
<?php get_footer(); ?>
