<?php
/**
 * Template Name: Careers Page
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="page-banner">
			<p class="eyebrow" style="justify-content:center;"><?php esc_html_e( 'Careers', 'mahadeva-ai' ); ?></p>
			<h1><?php the_title(); ?></h1>
			<?php if ( get_the_content() ) : ?><div class="lede" style="margin-inline:auto;"><?php the_content(); ?></div><?php endif; ?>
		</div>
	<?php endwhile; ?>

	<div class="container section" style="padding-top:0;">
		<?php
		$jobs = new WP_Query( array( 'post_type' => 'job_opening', 'posts_per_page' => -1 ) );
		if ( $jobs->have_posts() ) :
			?>
			<div class="job-list">
				<?php while ( $jobs->have_posts() ) : $jobs->the_post(); ?>
					<div class="job-item">
						<div>
							<h4><?php the_title(); ?></h4>
							<div class="tags">
								<?php $loc = get_post_meta( get_the_ID(), 'job_location', true ); ?>
								<?php if ( $loc ) : ?><span><?php echo esc_html( $loc ); ?></span><?php endif; ?>
								<?php $type = get_post_meta( get_the_ID(), 'job_type', true ); ?>
								<?php if ( $type ) : ?><span><?php echo esc_html( $type ); ?></span><?php endif; ?>
							</div>
						</div>
						<?php $apply = get_post_meta( get_the_ID(), 'job_apply_url', true ) ?: get_permalink(); ?>
						<a class="btn btn-outline btn-sm" href="<?php echo esc_url( $apply ); ?>"><?php esc_html_e( 'Apply Now', 'mahadeva-ai' ); ?></a>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<p class="text-center"><?php esc_html_e( 'No open roles right now. Check back soon.', 'mahadeva-ai' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
