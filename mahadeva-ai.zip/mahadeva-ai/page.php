<?php
/**
 * Default page template.
 *
 * @package Mahadeva_AI
 */

get_header();
?>
<main id="main" class="site-main">
	<div class="container section">
		<?php while ( have_posts() ) : the_post(); ?>
			<div class="page-banner">
				<h1><?php the_title(); ?></h1>
			</div>
			<div class="page-content">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-thumb" style="margin-bottom:2.5rem;border:1px solid var(--line);overflow:hidden;"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php the_content(); ?>
					<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'mahadeva-ai' ),
						'after'  => '</div>',
					) );
					?>
				</div>
			</div>

			<?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer(); ?>
